#!/bin/bash

# Task 1: Create a file for each snake ID

# Next, create an array that contains code to extract only snake IDs

snakeID_array=($(cut -f 1 BTS_data.txt | grep -v ID | sort | uniq))

#Create a for-loop that creates the new file name for every snake ID

for i in ${snakeID_array[@]}

do echo "file_$i"

done > snakeID_folder



# Task 2: Create files for every snake ID 

# create a while read-loop to create a file for every snake ID inside the snakeID_folder file

while read t 

do touch $t

done < snakeID_folder



#Optional:

# Create a new directory to place individual snake files into

#mkdir Assn3_dir 

# copy or move ALL files into new directory. Use wildcard to move all files
#cp file_13BTS* Assn3_dir



# Task 3: Place individual records for every snake ID, in the corresponding folders

# Use a while loop

COUNTER=0

Array_B=($(for i in {001..685}; do grep BTS$i BTS_data.txt; done))

while [ $COUNTER -lt 425 ]

do Array_B[$COUNTER]

let COUNTER=COUNTER+1

done




#Other options:

#	iterate through array


#How to break this section down:
#	make a list of snake IDs to work from

#	make a small test file using only a small subset of snake IDs



# Task 4: Clearly report the number of  files that were created by  your script to STDOUT

# To do this, you must know how many snakes are in the BTS_data.txt file (424 snakes)
# Use cut, grep, and uniq commands to find non-repeated snakeID names. Use the wc command to count the number of snakeIDs present


# Confirm the number of snakes(snakeIDs) on your command line
# Here is how the code should look: $ cut -f 1 BTS_data.txt| grep -v ID | uniq | wc -l


# Report the number of files to STDOUT using an array. In the array, use the code previously used to create file names for each individual snakeID. 

# Use echo command to show the value of the array and print to STDOUT

STDOUT_snake_array=($(for i in ${snakeID_array[@]}; do echo "file_$i"; done))

echo "${#STDOUT_snake_array[@]} files were created!"



# How to move script from ubuntu to github

	# create git repository on ubuntu and send to github on ubuntu

	# save file to thumbdrive, copy and paste to windows, create local gitrepo and link to remote gi>

